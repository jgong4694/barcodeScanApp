package kbar3.amkor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmkorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmkorApplication.class, args);
	}

}
