package kbar3.amkor.dto;

import lombok.Data;

@Data
public class testDto {
	private int machineId;
	private String machineName;
}
