package kbar3.amkor.service;

import java.util.List;

import kbar3.amkor.dto.testDto;

public interface AmkorServiceInterface {
	List<testDto> testFind();
}
