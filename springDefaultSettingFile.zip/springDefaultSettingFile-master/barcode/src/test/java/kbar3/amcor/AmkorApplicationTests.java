package kbar3.amcor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmkorApplicationTests {

	@Test
	void contextLoads() {
	}

}
